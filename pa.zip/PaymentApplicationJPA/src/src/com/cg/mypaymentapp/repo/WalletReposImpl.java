package src.com.cg.mypaymentapp.repo;
import javax.persistence.Query;
import java.math.BigDecimal;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import src.com.cg.mypaymentapp.beans.Customer;
import src.com.cg.mypaymentapp.beans.Wallet;
import src.com.cg.mypaymentapp.exception.InsufficientBalanceException;
import src.com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletReposImpl implements WalletRepo {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
	EntityManager em=emf.createEntityManager();
	EntityTransaction tr=em.getTransaction();
	public WalletReposImpl() {
	}

	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		if(findOne(mobileno)==null)
		{
		Wallet w4 = new Wallet(amount);
		Customer c4  = new Customer(name, mobileno, w4);
		save(c4);
		return c4;
		}
		else
		{
			try{
			throw new InvalidInputException("user alredy exists");
		}catch(InvalidInputException ie)
		{
			System.out.println(ie.getMessage());
		}
		}
		return null;
	}

	public Customer showBalance(String mobileno) {
		if (findOne(mobileno) != null) {
			System.out.println("Balance:"+findOne(mobileno).getWallet().getBalance());
			return findOne(mobileno);
		} else {
			System.out.println("Account Does Not Exists");
			return null;
		}

	}
	

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		if ((findOne(sourceMobileNo).getWallet().getBalance()).compareTo(amount) < 0){
			try{
				throw new InsufficientBalanceException("insufficient balance");
			}
			catch(InsufficientBalanceException ine)
			{
				System.out.println(ine.getMessage());
			}
		}
		if (((findOne(sourceMobileNo)) != null) && ((findOne(targetMobileNo))!= null)  ){
			if ((findOne(sourceMobileNo).getWallet().getBalance()).compareTo(amount) >= 0) {
				BigDecimal x = findOne(sourceMobileNo).getWallet().getBalance();
				x = x.subtract(amount);
				tr.begin();
				Wallet w1=findOne(sourceMobileNo).getWallet();
				w1.setBalance(x);
				em.merge(w1);
				BigDecimal y =findOne(targetMobileNo).getWallet().getBalance();
				y = y.add(amount);
				Wallet w2=findOne(targetMobileNo).getWallet();
				w2.setBalance(y);
				em.merge(w2);
				tr.commit();
				System.out.println("trancation successful");
			} 
		} else {
			System.out.println("source moblie number or target mobile number does not exists");
		}

		return findOne(targetMobileNo);

	}
	
	
	public Customer depositAmount(String mobileNo, BigDecimal amount)
	{
		if(findOne(mobileNo) != null)
		{	tr.begin();
			BigDecimal z=findOne(mobileNo).getWallet().getBalance();
			z=z.add(amount);
			Wallet w2= findOne(mobileNo).getWallet();
			w2.setBalance(z);
			em.merge(w2);
			tr.commit();
		}
		else
		{
			System.out.println("account does not exist");
		}
		return findOne(mobileNo);
		
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
	{
		
		if(findOne(mobileNo)!= null)
		{tr.begin();
			BigDecimal p=findOne(mobileNo).getWallet().getBalance();
			p=p.subtract(amount);
			Wallet w2 =findOne(mobileNo).getWallet();
			w2.setBalance(p);
			em.merge(w2);
			tr.commit();
		}
		else
		{
			System.out.println("account does not exist");
		}
		return findOne(mobileNo);
		
	}


	@Override
	public boolean save(Customer customer) {
			tr.begin();
			em.persist(customer);
			tr.commit();
			return true;
			}

	@Override
	public Customer findOne(String mobileNo) {
		Customer result=null;
		Query q= em.createQuery("from Customer c where c.mobileNo=?1");
		q.setParameter(1,mobileNo);
		q.setMaxResults(1);
		List<Customer> custlist=q.getResultList();
		if(custlist.size()>0)
		{
			result=custlist.get(0);
			return result;
		}
		return null;
	}

}
