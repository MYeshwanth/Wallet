package src.com.cg.mypaymentapp.pl;

import java.math.BigDecimal;

import java.util.Scanner;

import src.com.cg.mypaymentapp.beans.Customer;
import src.com.cg.mypaymentapp.service.WalletService;
import src.com.cg.mypaymentapp.service.WalletServiceImpl;
import src.com.cg.mypaymentapp.repo.*;

public class PaymentAppUI {
public static void main(String[] args) {
	WalletService service;
	service=new WalletServiceImpl();
	Scanner sc=new Scanner(System.in);
	int ch;
	while(true)
	{   entryArguments();
		ch=sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("enter the name");
			String name=sc.next();
			System.out.println("enter the phone number");
			String mobileno=sc.next();
			System.out.println("enter the amount");
			BigDecimal amount=sc.nextBigDecimal();
			service.createAccount(name,mobileno,amount);
			
			break;
			
		case 2:
			System.out.println("enter the mobile number to chech the balance");
			String mobileno1=sc.next();
			service.showBalance(mobileno1);
			break;
		
		case 3:
			System.out.println("enter the source , destination and amount to transfer the money ");
			String sm=sc.next();
			String dm=sc.next();
			BigDecimal a=sc.nextBigDecimal();

			break;
		case 4:
			System.out.println("enter mobilnumber and amount to deposit");
			String mn=sc.next();
			BigDecimal am=sc.nextBigDecimal();
			service.depositAmount(mn, am);
			break;
			
		case 5:
			System.out.println("enter mobilnumber and amount to withdraw");
			String mn1=sc.next();
			BigDecimal am1=sc.nextBigDecimal();
			service.withdrawAmount(mn1, am1);
			break;


		default:System.out.println("Please enter any of the integer to perform action");

			break;
		}
	}
}
public static void entryArguments() // Repeatedly asking options
{
	System.out.println("Enter 1 to create account\n" + "enter 2 check balance\n" + "Enter 3 to fund transfer\n" + "Enter 4 to deposit\n" + "Enter 5 to withdraw\n");

}
}
