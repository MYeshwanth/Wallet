package src.com.cg.mypaymentapp.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Cascade;

@Entity 
public class Customer {
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq1")
@SequenceGenerator(name = "seq1", sequenceName = "z4", initialValue =100, allocationSize = 1)
	private int customerid;
	private String name;
	private String mobileNo;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="walletid")
	private Wallet wallet;
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(String name2, String mobileNo2, Wallet wallet2) {
		this.name = name2;
		mobileNo = mobileNo2;
		wallet = wallet2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", name=" + name + ", mobileNo=" + mobileNo + ", wallet=" + wallet
				+ "]";
	}

	
}
