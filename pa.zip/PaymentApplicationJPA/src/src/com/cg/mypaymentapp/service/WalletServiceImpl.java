package src.com.cg.mypaymentapp.service;

import java.math.BigDecimal;


import src.com.cg.mypaymentapp.beans.Customer;
import src.com.cg.mypaymentapp.repo.WalletRepo;
import src.com.cg.mypaymentapp.repo.WalletReposImpl;

public class WalletServiceImpl implements WalletService {
	private WalletRepo repository;

	public WalletServiceImpl() {
		repository = new WalletReposImpl();

	}

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		// TODO Auto-generated method stub
		return repository.createAccount(name, mobileno, amount);
	}

	@Override
	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		return repository.showBalance(mobileno);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return repository.fundTransfer(sourceMobileNo, targetMobileNo, amount);
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return repository.depositAmount(mobileNo,amount);
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return repository.withdrawAmount(mobileNo, amount);
	}

}
